context("SafeAccount")

test_that("implementation for SafeAccount works", {
  initial_balance <- 1000
  account <- SafeAccount$new(initial_balance)
  checkmate::expect_r6(account, "SafeAccount")

  account$deposit(100)
  expect_equivalent(account$balance, 1100)

  account$withdraw(200)
  expect_equivalent(account$balance, 900)

  account$withdraw(1000)
  expect_equivalent(account$balance, -100)

  expect_error(account$withdraw(-10), regexp = "not >= 0")
  expect_error(account$deposit(-10), regexp = "not >= 0")

  expect_equivalent(account$log$log[, "transaction"],
                    c("deposit", "deposit", "withdraw", "withdraw"))
  expect_equivalent(account$log$log[, "amount"],
                    c(1000, 100, 200, 1000))
})


test_that("active binding for SafeAccount$balance works", {
  account <- SafeAccount$new(100)
  account$balance <- 1000
  expect_equivalent(account$balance, 1000)
  account$balance <- 900
  expect_equivalent(account$log$log[, "amount"],
                    c(100, 900, 100))
  expect_error(account$balance <- NA, "not be NA")
})

test_that("cloning behavior for SafeAccount works as expected", {
  account_1 <- SafeAccount$new(100)
  account_2a <- account_1$clone()
  account_2b <- account_1$clone(deep =  TRUE)
  account_3 <- account_1$clone2()

  expect_true(nrow(account_2a$log$log) == nrow(account_2b$log$log))
  account_1$balance <- 200
  expect_true(nrow(account_2a$log$log) == 2)
  expect_true(nrow(account_2b$log$log) == 1)
  expect_true(nrow(account_3$log$log) == 1)
})
