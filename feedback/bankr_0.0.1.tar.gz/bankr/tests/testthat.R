library(testthat)
library(bankr)

test_check("bankr")
