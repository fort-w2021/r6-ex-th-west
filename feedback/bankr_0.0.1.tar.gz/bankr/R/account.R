#' R6 Class Account
#'
#'@description An R6 class representing a generic bank account.
#'
#' An account has a balance and provides operations on this balance.
#' @import R6
#' @import checkmate
Account <- R6Class(
  "Account",
  public = list(
    #' @field balance how much money is there?
    balance = 0,
    #' @field account_holder whose money is it?
    account_holder =  person(),
    #' @description
    #' Create a new Account object.
    #' @param balance Initial account balance.
    #' @param account_holder Owner of the account
    #' @return A new `Account` object.
    initialize = function(balance = 0, account_holder = person()) {
      self$balance <- balance
      self$account_holder <- account_holder
      self$validate()
    },
    #' @description
    #' Validate a bank account.
    #' @return self
    #' @import checkmate
    validate = function() {
      assert_number(self$balance, finite = TRUE)
      assert_class(self$account_holder, "person")
      invisible(self)
    },
    #' @description
    #' Print text summary of bank account.
    #' @return self
    print = function() {
      cat("Account: \n")
      cat("  Name:", print(self$account_holder), "\n")
      cat("  Balance:  ", format(self$balance, digits = 2), "\n")
      invisible(self)
    },
    #' @description
    #' Deposit money into account.
    #' @param amount Amount of money
    #' @return self
    deposit = function(amount) {
      assert_number(amount, lower = 0, finite = TRUE)
      private$..update(amount)
    },
    #' @description
    #' Withdraw money from account.
    #' @param amount Amount of money
    #' @return self
    withdraw = function(amount) {
      assert_number(amount, lower = 0, finite = TRUE)
      private$..update(-amount)
    }
  ),
  private = list(
      ..update = function(amount) {
      self$balance <- self$balance + amount
      invisible(self)
    }
  )
)


#' R6 Class representing a giro bank account
#'
#' It has an overdraft limit and withdraws fees for
#' negative account balance.
#' @seealso [Account]
#' @import R6
GiroAccount <- R6Class(
  "GiroAccount",
  inherit = Account,
  private = list(
    ..overdraft_max = Inf,
    ..overdraft_rate = 0
  ),
  public = list(
    #' @description
    #' Create a new GiroAccount object.
    #' @param balance Initial account balance.
    #' @param account_holder Owner of the account
    #' @param overdraft_max Maximal negative account balance
    #' @param overdraft_percentage Overdraft fee percentage
    #' @return A new `GiroAccount` object.
    initialize = function(balance = 0, account_holder = person(),
                          overdraft_max = Inf, overdraft_percentage = 0) {
      super$initialize(balance, account_holder)
      private$..overdraft_max <- overdraft_max
      private$..overdraft_rate <- overdraft_percentage/100
      self$validate()
    },
    #' @description
    #' Validate a freshly opened bank account.
    #' @return NULL
    validate = function() {
      super$validate()
      assert_number(private$..overdraft_max, lower = 0)
      assert_number(private$..overdraft_rate,
                               lower = 0, upper = 100)
      invisible(self)
    },
    #' @description Draw additional fee when overdraft limit exceeded.
    #' @param amount Amount of money
    #'
    #' @return self
    withdraw = function(amount) {
      new_balance <- self$balance - amount
      fee <- 0
      if (new_balance < 0) {
        fee <- - (new_balance * private$..overdraft_rate)
        new_balance <- new_balance - fee
        amount <- amount + fee
      }
      if (new_balance < -private$..overdraft_max) {
        stop("Insufficient funds.")
      }
      if (fee != 0) {
        warning("Overcharge fee: ", -fee)
      }
      super$withdraw(amount)
      invisible(self)
    }
  )
)
